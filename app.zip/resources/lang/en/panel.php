<?php

return [
    'site_title' => 'Language Links',
];
