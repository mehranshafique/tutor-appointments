
<?php $__env->startSection('content'); ?>

  <div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.user.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.users.update", [$user->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
              <div class="col-lg-6">
                <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                    <label for="name"><?php echo e(trans('cruds.user.fields.name')); ?>*</label>
                    <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($user) ? $user->name : '')); ?>" required>
                    <?php if($errors->has('name')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('name')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.name_helper')); ?>

                    </p>
                </div>
                <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                    <label for="email"><?php echo e(trans('cruds.user.fields.email')); ?>*</label>
                    <input type="email" id="email" name="email" class="form-control" value="<?php echo e(old('email', isset($user) ? $user->email : '')); ?>" required>
                    <?php if($errors->has('email')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('email')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.email_helper')); ?>

                    </p>
                </div>

                <div class="form-group <?php echo e($errors->has('introduction') ? 'has-error' : ''); ?>">
                    <label for="email"><?php echo e(trans('cruds.user.fields.introduction')); ?>*</label>
                    <input type="text" id="introduction" name="introduction" class="form-control" value="<?php echo e(old('introduction', isset($user) ? $user->introduction : '')); ?>" >
                    <?php if($errors->has('introduction')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('introduction')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.introduction_helper')); ?>

                    </p>
                </div>

                <div class="form-group <?php echo e($errors->has('dob') ? 'has-error' : ''); ?>">
                    <label for="dob"><?php echo e(trans('cruds.user.fields.dob')); ?>*</label>
                    <input type="date" id="dob" name="dob" class="form-control" value="<?php echo e(old('dob', isset($user) ? $user->dob : '')); ?>" >
                    <?php if($errors->has('dob')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('dob')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.dob_helper')); ?>

                    </p>
                </div>

                <div class="form-group <?php echo e($errors->has('user_type') ? 'has-error' : ''); ?>">
                    <label for="user_type"><?php echo e(trans('cruds.user.fields.user_type')); ?>*</label>
                    <select name="user_type" id="user_type" required class="form-control">
                      <option value="1"> <?php echo e(trans('cruds.user.fields.admin')); ?></option>
                        <option value="2"> <?php echo e(trans('cruds.user.fields.teacher')); ?></option>
                        <option value="3"> <?php echo e(trans('cruds.user.fields.student')); ?></option>
                    </select>
                    <?php if($errors->has('user_type')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('user_type')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.user_type_helper')); ?>

                    </p>
                </div>

                <div id="hourly_pay" class="form-group <?php echo e($errors->has('hourly_pay') ? 'has-error' : ''); ?> <?php echo e(isset($user->hourly_pay) ? 'd-block' : 'd-none'); ?>">
                    <label for="hourly_pay"><?php echo e(trans('cruds.user.fields.hourly_pay')); ?>*</label>
                    <input type="text"  name="hourly_pay" class="form-control" value="<?php echo e(old('hourly_pay', isset($user) ? $user->hourly_pay : '')); ?>" >
                    <?php if($errors->has('hourly_pay')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('hourly_pay')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.hourly_pay_helper')); ?>

                    </p>
                </div>

                <div class="form-group teacherFields <?php echo e($errors->has('services') ? 'has-error' : ''); ?> <?php echo e(isset($user->services[0]) ? 'd-block' : 'd-none'); ?>">
                    <label for="services"><?php echo e(trans('cruds.teacher.fields.services')); ?>

                        <span class="btn btn-info btn-xs select-all"><?php echo e(trans('global.select_all')); ?></span>
                        <span class="btn btn-info btn-xs deselect-all"><?php echo e(trans('global.deselect_all')); ?></span></label>
                    <select name="services[]" id="services" class="form-control select2" multiple="multiple">
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('services', [])) || isset($teacher) && $teacher->services->contains($id)) ? 'selected' : ''); ?>><?php echo e($services); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('services')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('services')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.teacher.fields.services_helper')); ?>

                    </p>
                </div>
                
                <div class="form-group <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
                    <label for="gender"><?php echo e(trans('cruds.user.fields.status')); ?>*</label>
                    <select name="gender" id="gender" required class="form-control">
                        <option value="1"> <?php echo e(trans('cruds.user.fields.male')); ?></option>
                        <option value="0"> <?php echo e(trans('cruds.user.fields.female')); ?></option>
                    </select>
                    <?php if($errors->has('gender')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('gender')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.gender_helper')); ?>

                    </p>
                </div>

                <div class="form-group <?php echo e($errors->has('avatar') ? 'has-error' : ''); ?>">
                    <label for="avatar"><?php echo e(trans('cruds.user.fields.picture')); ?>*</label>
                    <input type="file" name="avatar" id="avatar" class="form-control" value="<?php echo e(old('avatar', isset($user) ? $user->avatar : '')); ?>" >
                    <?php if($errors->has('avatar')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('avatar')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.avatar_helper')); ?>

                    </p>
                </div>

                <div class="form-group <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
                    <label for="status"><?php echo e(trans('cruds.user.fields.status')); ?>*</label>
                    <select name="status" id="status" required class="form-control">
                        <option value="1"> <?php echo e(trans('cruds.user.fields.active')); ?></option>
                        <option value="0"> <?php echo e(trans('cruds.user.fields.block')); ?></option>
                    </select>
                    <?php if($errors->has('status')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('status')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.status_helper')); ?>

                    </p>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                    <label for="phone"><?php echo e(trans('cruds.user.fields.phone')); ?>*</label>
                    <input type="number" name="phone" id="phone"  class="form-control" value="<?php echo e(old('phone', isset($user) ? $user->phone : '')); ?>" >
                    <?php if($errors->has('phone')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('phone')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.phone_helper')); ?>

                    </p>
                </div>
                <div class="form-group <?php echo e($errors->has('location') ? 'has-error' : ''); ?>">
                    <label for="location"><?php echo e(trans('cruds.user.fields.location')); ?>*</label>
                    <input type="text" name="location" id="location" name="location" class="form-control" value="<?php echo e(old('location', isset($user) ? $user->location : '')); ?>" >
                    <?php if($errors->has('location')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('location')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.location_helper')); ?>

                    </p>
                </div>

                <div class="form-group <?php echo e($errors->has('country') ? 'has-error' : ''); ?>">
                    <label for="country"><?php echo e(trans('cruds.user.fields.country')); ?>*</label>
                    <select name="country" id="country" required class="form-control">
                        <option value="1"> Pakistan</option>
                        <option value="2"> US</option>
                    </select>
                    <?php if($errors->has('country')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('country')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.country_helper')); ?>

                    </p>
                </div>

                <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                    <label for="password"><?php echo e(trans('cruds.user.fields.password')); ?></label>
                    <input type="password" id="password" name="password" class="form-control" >
                    <?php if($errors->has('password')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('password')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.password_helper')); ?>

                    </p>
                </div>
                <div class="form-group <?php echo e($errors->has('roles') ? 'has-error' : ''); ?>">
                    <label for="roles"><?php echo e(trans('cruds.user.fields.roles')); ?>*
                        <span class="btn btn-info btn-xs select-all"><?php echo e(trans('global.select_all')); ?></span>
                        <span class="btn btn-info btn-xs deselect-all"><?php echo e(trans('global.deselect_all')); ?></span></label>
                    <select name="roles[]" id="roles" class="form-control select2" multiple="multiple" required>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('roles', [])) || isset($user) && $user->roles->contains($id)) ? 'selected' : ''); ?>><?php echo e($roles); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('roles')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('roles')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.user.fields.roles_helper')); ?>

                    </p>
                </div>
                <div>
                    <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
                </div>
              </div>
            </div>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script type="text/javascript">
  $('#user_type').on('change', function() {
    if(this.value == <?php echo e(App\UserInterFace::TEACHER_ROLE_ID); ?>){
      $('.teacherFields').removeClass('d-none');
    }else{
      $('.teacherFields').addClass('d-none');
    }
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Appointments\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>