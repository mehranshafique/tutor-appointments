
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.teacher.title_singular')); ?>

    </div>

    <div class="card-body">
      <form action="<?php echo e(route("admin.availbilities.store")); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group <?php echo e($errors->has('teacher_id') ? 'has-error' : ''); ?>">
              <label for="employee"><?php echo e(trans('cruds.appointment.fields.employee')); ?></label>
              <select name="teacher_id" id="employee" class="form-control select2">
                  <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($id); ?>" <?php echo e((isset($appointment) && $appointment->employee ? $appointment->employee->id : old('employee_id')) == $id ? 'selected' : ''); ?>><?php echo e($employee); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php if($errors->has('teacher_id')): ?>
                  <em class="invalid-feedback">
                      <?php echo e($errors->first('teacher_id')); ?>

                  </em>
              <?php endif; ?>
          </div>
          <div class="form-group <?php echo e($errors->has('start_time') ? 'has-error' : ''); ?>">
              <label for="start_time"><?php echo e(trans('cruds.appointment.fields.start_time')); ?>*</label>
              <input type="text" id="start_time" name="start_time" class="form-control datetime" value="<?php echo e(old('start_time', isset($appointment) ? $appointment->start_time : '')); ?>" required>
              <?php if($errors->has('start_time')): ?>
                  <em class="invalid-feedback">
                      <?php echo e($errors->first('start_time')); ?>

                  </em>
              <?php endif; ?>
              <p class="helper-block">
                  <?php echo e(trans('cruds.appointment.fields.start_time_helper')); ?>

              </p>
          </div>
          <div class="form-group <?php echo e($errors->has('finish_time') ? 'has-error' : ''); ?>">
              <label for="finish_time"><?php echo e(trans('cruds.appointment.fields.finish_time')); ?>*</label>
              <input type="text" id="finish_time" name="finish_time" class="form-control datetime" value="<?php echo e(old('finish_time', isset($appointment) ? $appointment->finish_time : '')); ?>" required>
              <?php if($errors->has('finish_time')): ?>
                  <em class="invalid-feedback">
                      <?php echo e($errors->first('finish_time')); ?>

                  </em>
              <?php endif; ?>
              <p class="helper-block">
                  <?php echo e(trans('cruds.appointment.fields.finish_time_helper')); ?>

              </p>
          </div>

          <div class="form-group <?php echo e($errors->has('comments') ? 'has-error' : ''); ?>">
              <label for="comments"><?php echo e(trans('cruds.appointment.fields.comments')); ?></label>
              <textarea id="comments" name="comments" class="form-control "><?php echo e(old('comments', isset($appointment) ? $appointment->comments : '')); ?></textarea>
              <?php if($errors->has('comments')): ?>
                  <em class="invalid-feedback">
                      <?php echo e($errors->first('comments')); ?>

                  </em>
              <?php endif; ?>
              <p class="helper-block">
                  <?php echo e(trans('cruds.appointment.fields.comments_helper')); ?>

              </p>
          </div>
          <div>
              <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
          </div>
      </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.photoDropzone = {
    url: '<?php echo e(route('admin.teachers.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="photo"]').remove()
      $('form').append('<input type="hidden" name="photo" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="photo"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($teacher) && $teacher->photo): ?>
      var file = <?php echo json_encode($teacher->photo); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.url)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="photo" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Appointments\resources\views/admin/teacher-availbilities/create.blade.php ENDPATH**/ ?>