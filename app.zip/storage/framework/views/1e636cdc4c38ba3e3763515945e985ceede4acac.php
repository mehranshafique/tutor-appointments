
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.child_subjects.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.child-subjects.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group <?php echo e($errors->has('subject_id') ? 'has-error' : ''); ?>">
                <label for="subject_id"><?php echo e(trans('cruds.child_subjects.fields.name')); ?>*</label>
                <select name="subject_id" id="subject_id" required class="form-control">
                  <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('subject_id')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('subject_id')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.child_subjects.fields.name_helper')); ?>

                </p>
            </div>

            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                <label for="name"><?php echo e(trans('cruds.child_subjects.fields.curriculum')); ?>*</label>
                <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', isset($service) ? $service->name : '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.child_subjects.fields.name_helper')); ?>

                </p>
            </div>

            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                <label for="description"><?php echo e(trans('cruds.child_subjects.fields.description')); ?>*</label>
                <input type="text" id="description" name="description" class="form-control" value="<?php echo e(old('description', isset($service) ? $service->description : '')); ?>" required>
                <?php if($errors->has('description')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('description')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.child_subjects.fields.description_helper')); ?>

                </p>
            </div>

            <div class="form-group <?php echo e($errors->has('picture') ? 'has-error' : ''); ?>">
                <label for="picture"><?php echo e(trans('cruds.child_subjects.fields.picture')); ?>*</label>
                <input type="file" id="picture" name="picture" class="form-control" value="<?php echo e(old('picture', isset($service) ? $service->picture : '')); ?>" >
                <?php if($errors->has('picture')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('picture')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.child_subjects.fields.picture_helper')); ?>

                </p>
            </div>

            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Appointments\resources\views/admin/child_subjects/create.blade.php ENDPATH**/ ?>