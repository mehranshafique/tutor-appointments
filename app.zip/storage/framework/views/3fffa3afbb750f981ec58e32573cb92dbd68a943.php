
<?php $__env->startSection('content'); ?>
<style>
</style>
<div class="container">
    <div class="main-body">

          <!-- Breadcrumb -->
          <nav aria-label="breadcrumb" class="main-breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="/">Home</a></li>
              <li class="breadcrumb-item"><a href="javascript:void(0)">Teachers</a></li>
              <li class="breadcrumb-item active" aria-current="page">Teacher Profile</li>
            </ol>
          </nav>
          <!-- /Breadcrumb -->

          <div class="row gutters-sm">
            <div class="col-md-4 mb-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex flex-column align-items-center text-center">
                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="Admin" class="rounded-circle" width="150">
                    <div class="mt-3">
                      <h4><?php echo e($teacher->name); ?></h4>
                      <p class="text-muted font-size-sm">Location: <?php echo e($teacher->location); ?></p>
                      <button class="btn btn-primary" data-toggle="modal" data-target="#appointmentBookModal" >Book Session</button>
                      <!-- <button class="btn btn-outline-primary">Message</button> -->
                    </div>
                  </div>
                </div>
              </div>
              <div class="card mt-3">
                <h3 class="text-center">Teacher Availbility</h3>
                <ul class="list-group list-group-flush">
                  <?php $__currentLoopData = $teacher_availbilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher_availbility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                    <h6 class="mb-0"><?php echo e($teacher_availbility->start_time); ?></h6>
                    <span class="text-primary">Till: <?php echo e($teacher_availbility->finish_time); ?></span>
                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
            </div>
            <div class="col-md-8">
              <div class="card mb-3">
                <div class="card-body">
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Full Name</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo e($teacher->name); ?>

                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Email</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo e($teacher->email); ?>

                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">About</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo e($teacher->introduction); ?>

                    </div>
                  </div>
                  <hr>
                  <div class="row">
                    <div class="col-sm-3">
                      <h6 class="mb-0">Address</h6>
                    </div>
                    <div class="col-sm-9 text-secondary">
                      <?php echo e($teacher->location); ?>

                    </div>
                  </div>
                  <hr>

                </div>
              </div>

              <div class="row gutters-sm">
                <div class="col-sm-6 mb-3">
                  <div class="card h-100">
                    <div class="card-body">
                      <h6 class="d-flex align-items-center mb-3">
                        <i class="material-icons text-info mr-2">Languages</i></h6>
                      <?php $__currentLoopData = $teacher->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <small><?php echo e($service->name); ?></small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 mb-3">
                  <div class="card h-100">
                    <div class="card-body">
                      <h6 class="d-flex align-items-center mb-3"><i class="material-icons text-info mr-2">Subjects </i> </h6>
                      <?php $__currentLoopData = $teacher->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <small><?php echo e($service->name); ?></small>
                      <div class="progress mb-3" style="height: 5px">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                      </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                  </div>
                </div>
              </div>



            </div>
          </div>

        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="appointmentBookModal" tabindex="-1" role="dialog" aria-labelledby="appointmentBookModalTitle" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.appointment.title_singular')); ?></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>

            <form action="<?php echo e(route("student.appointments.store")); ?>" method="POST" enctype="multipart/form-data">
              <div class="modal-body">
                <?php echo method_field('post'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group <?php echo e($errors->has('client_id') ? 'has-error' : ''); ?>">
                    <label for="client"><?php echo e(trans('cruds.appointment.fields.client')); ?>*</label>
                    <select name="client_id" id="client" class="form-control select2" required>
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e((isset($appointment) && $appointment->client ? $appointment->client->id : old('client_id')) == $id ? 'selected' : ''); ?>><?php echo e($client); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('client_id')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('client_id')); ?>

                        </em>
                    <?php endif; ?>
                </div>
                <div class="form-group <?php echo e($errors->has('employee_id') ? 'has-error' : ''); ?>">
                    <label for="employee"><?php echo e(trans('cruds.appointment.fields.employee')); ?></label>
                    <select name="employee_id" id="employee" class="form-control select2">
                        <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e((isset($appointment) && $appointment->employee ? $appointment->employee->id : old('employee_id')) == $id ? 'selected' : ''); ?>><?php echo e($employee); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('employee_id')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('employee_id')); ?>

                        </em>
                    <?php endif; ?>
                </div>
                <div class="form-group <?php echo e($errors->has('start_time') ? 'has-error' : ''); ?>">
                    <label for="start_time"><?php echo e(trans('cruds.appointment.fields.start_time')); ?>*</label>
                    <input type="text" id="start_time" name="start_time" class="form-control datetime" value="<?php echo e(old('start_time', isset($appointment) ? $appointment->start_time : '')); ?>" required>

                    <?php if($errors->has('start_time')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('start_time')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.appointment.fields.start_time_helper')); ?>

                    </p>
                </div>
                <div class="form-group <?php echo e($errors->has('finish_time') ? 'has-error' : ''); ?>">
                    <label for="finish_time"><?php echo e(trans('cruds.appointment.fields.finish_time')); ?>*</label>
                    <input type="text" id="finish_time" name="finish_time" class="form-control datetime" value="<?php echo e(old('finish_time', isset($appointment) ? $appointment->finish_time : '')); ?>" required>
                    <?php if($errors->has('finish_time')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('finish_time')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.appointment.fields.finish_time_helper')); ?>

                    </p>
                </div>

                <div class="form-group <?php echo e($errors->has('comments') ? 'has-error' : ''); ?>">
                    <label for="comments"><?php echo e(trans('cruds.appointment.fields.comments')); ?></label>
                    <textarea id="comments" name="comments" class="form-control "><?php echo e(old('comments', isset($appointment) ? $appointment->comments : '')); ?></textarea>
                    <?php if($errors->has('comments')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('comments')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.appointment.fields.comments_helper')); ?>

                    </p>
                </div>
                <div class="form-group <?php echo e($errors->has('services') ? 'has-error' : ''); ?>">
                    <label for="services"><?php echo e(trans('cruds.appointment.fields.services')); ?>

                        <span class="btn btn-info btn-xs select-all"><?php echo e(trans('global.select_all')); ?></span>
                        <span class="btn btn-info btn-xs deselect-all"><?php echo e(trans('global.deselect_all')); ?></span></label>
                    <select name="services[]" id="services" class="form-control select2" multiple="multiple">
                        <?php $__currentLoopData = $teacher->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($service->id); ?>" <?php echo e((in_array($id, old('services', [])) || isset($appointment) && $appointment->service->contains($id)) ? 'selected' : ''); ?>><?php echo e($service->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('services')): ?>
                        <em class="invalid-feedback">
                            <?php echo e($errors->first('services')); ?>

                        </em>
                    <?php endif; ?>
                    <p class="helper-block">
                        <?php echo e(trans('cruds.appointment.fields.services_helper')); ?>

                    </p>
                </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button  class="btn btn-primary"  type="submit" ><?php echo e(trans('global.save')); ?></button>
                </div>
            </form>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Appointments\resources\views/student/teacher-details.blade.php ENDPATH**/ ?>