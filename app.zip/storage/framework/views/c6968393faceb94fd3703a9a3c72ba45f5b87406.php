
<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.employee.title_singular')); ?>

    </div>

    <div class="card-body">
      <form action="<?php echo e(route("admin.availbilities.update", [$teacherAvailbility->id])); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
          <div class="form-group <?php echo e($errors->has('teacher_id') ? 'has-error' : ''); ?>">
              <label for="employee"><?php echo e(trans('cruds.appointment.fields.employee')); ?></label>
              <select name="teacher_id" id="employee" class="form-control select2">
                  <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($id); ?>" <?php echo e((isset($teacherAvailbility) && $teacherAvailbility->id ? $teacherAvailbility->teacher_id : old('teacher_id')) == $id ? 'selected' : ''); ?>><?php echo e($teacher); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              <?php if($errors->has('teacher_id')): ?>
                  <em class="invalid-feedback">
                      <?php echo e($errors->first('teacher_id')); ?>

                  </em>
              <?php endif; ?>
          </div>
          <div class="form-group <?php echo e($errors->has('start_time') ? 'has-error' : ''); ?>">
              <label for="start_time"><?php echo e(trans('cruds.appointment.fields.start_time')); ?>*</label>
              <input type="text" id="start_time" name="start_time" class="form-control datetime" value="<?php echo e(old('start_time', isset($teacherAvailbility) ? $teacherAvailbility->start_time : '')); ?>" required>
              <?php if($errors->has('start_time')): ?>
                  <em class="invalid-feedback">
                      <?php echo e($errors->first('start_time')); ?>

                  </em>
              <?php endif; ?>
              <p class="helper-block">
                  <?php echo e(trans('cruds.appointment.fields.start_time_helper')); ?>

              </p>
          </div>
          <div class="form-group <?php echo e($errors->has('finish_time') ? 'has-error' : ''); ?>">
              <label for="finish_time"><?php echo e(trans('cruds.appointment.fields.finish_time')); ?>*</label>
              <input type="text" id="finish_time" name="finish_time" class="form-control datetime" value="<?php echo e(old('finish_time', isset($teacherAvailbility) ? $teacherAvailbility->finish_time : '')); ?>" required>
              <?php if($errors->has('finish_time')): ?>
                  <em class="invalid-feedback">
                      <?php echo e($errors->first('finish_time')); ?>

                  </em>
              <?php endif; ?>
              <p class="helper-block">
                  <?php echo e(trans('cruds.appointment.fields.finish_time_helper')); ?>

              </p>
          </div>

          <div class="form-group <?php echo e($errors->has('comments') ? 'has-error' : ''); ?>">
              <label for="comments"><?php echo e(trans('cruds.appointment.fields.comments')); ?></label>
              <textarea id="comments" name="comments" class="form-control "><?php echo e(old('comments', isset($teacherAvailbility) ? $teacherAvailbility->comments : '')); ?></textarea>
              <?php if($errors->has('comments')): ?>
                  <em class="invalid-feedback">
                      <?php echo e($errors->first('comments')); ?>

                  </em>
              <?php endif; ?>
              <p class="helper-block">
                  <?php echo e(trans('cruds.appointment.fields.comments_helper')); ?>

              </p>
          </div>
          <div>
              <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
          </div>
      </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Appointments\resources\views/admin/teacher-availbilities/edit.blade.php ENDPATH**/ ?>